//
//  MJStudent.h
//  Interview01-cache
//
//  Created by MJ Lee on 2018/5/22.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@interface MJStudent : MJPerson
- (void)studentTest;
@end
